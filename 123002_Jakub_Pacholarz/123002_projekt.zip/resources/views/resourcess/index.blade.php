<!doctype html>
<html lang="pl">
  
  <body>
    @include('layout')
    <div id="start" class="mb-5">
    <div id="materials" class="container mb-5">
      <div class="row">
          
      
  </div>

  <div id="cennik" class="container mt-5 mb-5">
    <div class="row">
        <h1 style="text-align: center">Cennik</h1>
    </div>
    <table class="table table-hover table-striped">
        <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nazwa surowca</th>
                <th scope="col">Typ</th>
                <th scope="col">Cena za 1kg</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($resourcess as $t)
            <tr>
                <<th scope="row">{{$t->id}}</th>

                <td>
                    @php
                    $materials = DB::table('materials')->where('id', $t->id_materials)->first();
                    if ($materials) {
                       echo $materials->nazwa;
                    }
                    @endphp
                </td>
                <td>{{$t->typ}}</td>
                <td>{{$t->ilosc}}</td>
                
                @can('is-admin')
                <td><a href="{{route('materials.edit', $t->id)}}">Edycja</a></td>
                @endcan
            </tr>
            @empty
            <tr>
                <th scope="row" colspan="6">Brak surowcow.</th>
            </tr>
            @endforelse
        </tbody>
    </table>
  </div>

  <div id="inne" class="container mb-5">
    <div class="row">
        <div class="col-sm-12 col-md-6 mb-4">
           
           
        </div>
      
    </div>

  </body>
</html>
