<!doctype html>
<html lang="pl">



<body>
    @include('layout')

    <div class="container mt-5 mb-5">
        @if (session('error'))
            <div class="row d-flex justify-content-center">
                <div class="alert alert-danger">{{ session('error') }}</div>
            </div>
        @endif
        <div class="row mt-4 mb-4 text-center">
            <h1>Edytuj dane materials</h1>
        </div>

        @if ($errors->any())
            <div class="row d-flex justify-content-center">
                <div class="col-6">
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        @endif

        <div class="row d-flex justify-content-center">
            <div class="col-6">
                <form method="POST" action="{{ route('resourcess.update', $t->id) }}" class="needs-validation" novalidate>
                    @csrf
                    @method('PUT')
                    <div class="form-group mb-2">
                        <label for="nazwa">Nazwa</label>
                        <input id="nazwa" name="nazwa" type="text" class="form-control" value="{{ $t->nazwa }}">
                        <div class="invalid-feedback">Nieprawidłowe nazwa!</div>
                    </div>
                
                    <div class="form-group mb-2">
                        <label for="typ">Typ</label>
                        <input id="typ" name="typ" type="text" class="form-control" value="{{ $t->typ }}">
                    </div>

                    <div class="form-group mb-2">
                        <label for="ilosc">Ilosc</label>
                        <select id="ilosc" name="ilosc" class="form-select" value="{{ $t->ilosc }}">>
                    </div>

                    <div class="form-group mb-2">
                                <label for="id_materials">Materiał</label>
                                <input id="id_materials" name="id_materials" type="text" class="form-control" value="{{ $t->id_materials }}">
                    </div>

                        </select>
                    </div>
                    <div class="text-center mt-4 mb-4">
                        <input class="btn btn-success" type="submit" value="Wyślij">
                    </div>
                </form>
            </div>
        </div>
    </div>

    
</body>

</html>

