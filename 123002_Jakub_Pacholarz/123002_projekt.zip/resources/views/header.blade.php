<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
  body {font-family: "Lato", sans-serif}
  .mySlides {display: none}
  </style>
</head>
<div >
<nav class="navbar navbar-expand-lg bg-light">
    <div class="container-fluid" >
    
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          @auth


          <li>
            <a class="nav-link" href="{{route('home2')}}">Strona główna</a>
          </li>
          <li>
            <a class="nav-link" href="{{route('resourcess.index')}}">Cennik</a>
          </li>



          <li class="nav-item">
            <a class="nav-link" href="{{route('cennik')}}">Info</a>
          </li>


          <li>
            <a class="nav-link" href="{{route('about')}}">O Nas</a>
          </li>
          

          <li class="nav-item">
            <a class="nav-link" href="{{route('logout')}}">Wyloguj</a>
          </li>

          

          
          @else


          <li>
            <a class="nav-link" href="{{route('home')}}">Strona główna</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="{{route('cennik')}}">Info</a>
          </li>

          <li>
            <a class="nav-link" href="{{route('about')}}">O Nas</a>
          </li>

          <li>
            <a class="nav-link" href="{{route('resourcess.index')}}">Cennik</a>
          </li>

          

          <li class="nav-item">
            <a class="nav-link" href="{{route('login')}}">Login</a>
          </li>

          <li class="nav-item">
            <a class="nav-link" href="{{route('rejestracja')}}">Rejestracja</a>
          </li>

          

        
          
          @endauth

          
        </ul>
        <span class="navbar-text">@auth{{auth()->user()->name}}@endauth
        </span>
      </div>
    </div>
  </div>
  </nav>