@extends('layout')
@section('title', "O NAS")
@section('content')
<!DOCTYPE html>
<html>
<head>
    <title>Selling Company | History</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #1d1414;
            padding: 1%;
            color: #fff;
            text-align: center;
        }

    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #ffffff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 5px;
    }
    
    h1 {
        color: #333;
        text-align: center;
        margin-top: 0;
            margin: 0;
        padding-top: 20px;
    }
    
    h2 {
        color: #555;
        margin-top: 30px;
    }
    
    p {
        line-height: 1.6;
        color: #777;
    }
    
    ul {
        list-style-type: disc;
        padding-left: 20px;
        color: #777;
    }
    
    li {
        margin-bottom: 10px;
    }
    
    .contact-info {
        margin-top: 30px;
        color: #555;
    }
    
    .contact-info p {
        margin-bottom: 10px;
    }
    footer {
            background-color: #333;
            padding: 10px;
            color: #fff;
            text-align: center;
        }
</style>
</head>
<body>
    <div class="container">
        <h1 >Super Surowce</h1>

        <h2 style="text-align: center" >Nasza Historia</h2>
        <p>
          Witamy w firmie Selling Company, zaufanej nazwie w świecie sprzedaży i dystrybucji. Jesteśmy obecni na rynku od ponad 20 lat, zapewniając wyjątkowe usługi naszym klientom.
        </p>
      
        <p>
          Nasza podróż rozpoczęła się w 2003 roku, kiedy nasz założyciel, Jan Kowalski, dostrzegł potrzebę niezawodnej i efektywnej firmy sprzedażowej. Z wizją łączenia producentów i dostawców z detalistami, zaczęliśmy od małych rozmiarów, ale z ogromnym zaangażowaniem. Przez lata stopniowo rosliśmy i ugruntowaliśmy naszą pozycję jako lider w branży.
        </p>
      
        <p>
          W ciągu tego czasu Selling Company wypracowało silne relacje z rozległą siecią partnerów i klientów. Nasze zaangażowanie w jakość, integralność i satysfakcję klienta było fundamentem naszego sukcesu.
        </p>
      
        <h2 style="text-align: center">Nasza Misja</h2>
        <p>
          W firmie Selling Company naszą misją jest świadczenie wyjątkowych rozwiązań w zakresie sprzedaży i dystrybucji dla naszych klientów. Dążymy do przekraczania oczekiwań, dostarczając produkty najwyższej jakości, efektywną logistykę i doskonałą obsługę klienta.
        </p>
      
        <h2 style="text-align: center">Nasze Usługi</h2>
        <ul>
          <li>Sprzedaż i Marketing</li>
          <li>Zarządzanie Łańcuchem Dostaw</li>
          <li>Dystrybucja Produktów</li>
          <li>Zarządzanie Zapasami</li>
          <li>Wsparcie dla Detalistów</li>
          <li>Zarządzanie Relacjami z Klientem</li>
        </ul>
      
        <h2 style="text-align: center" >Kontakt</h2>
        <div class="contact-info">
          <p>
            Dziękujemy za zainteresowanie firmą Selling Company. W razie pytań lub chęci omówienia możliwości biznesowych, prosimy o kontakt z nami, korzystając z poniższych danych kontaktowych:
          </p>
      
          <p style="text-align: center">
            Email: info@sellingcompany.com<br>
            Telefon: +48 123-456-7890<br>
            Adres: ul. Główna 123, Miasto, Kod pocztowy
          </p>
        </div>
      </body>
      </html>



@endsection
