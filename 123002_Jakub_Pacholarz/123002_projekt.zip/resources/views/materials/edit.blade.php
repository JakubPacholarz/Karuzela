<!doctype html>
<html lang="pl">



<body>
    @include('layout')

    <div class="container mt-5 mb-5">
        @if (session('error'))
            <div class="row d-flex justify-content-center">
                <div class="alert alert-danger">{{ session('error') }}</div>
            </div>
        @endif
        <div class="row mt-4 mb-4 text-center">
            <h1>Edytuj dane surowca</h1>
        </div>

        @if ($errors->any())
            <div class="row d-flex justify-content-center">
                <div class="col-6">
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        @endif

        <div class="row d-flex justify-content-center">
            <div class="col-6">
                <form method="POST" action="{{ route('materials.update', $s->id) }}" class="needs-validation" novalidate>
                    @csrf
                    @method('PUT')
                    <div class="form-group mb-2">
                        <label for="nazwa">Nazwa</label>
                        <input id="nazwa" name="nazwa" type="text" class="form-control" value="{{ $s->nazwa }}">
                        
                    </div>
                    
                    <div class="form-group mb-2">
                        <label for="price">Cena</label>
                        <input id="price" name="price" type="text" class="form-control" value="{{ $s->price }}">
                        
                    </div>


                    <div class="text-center mt-4 mb-4">
                        @can('is-admin') 
                        <input class="btn btn-success" type="submit" value="Wyślij">
                        @endcan
                    </div>
                </form>
            </div>
        </div>
    </div>

   
</body>

</html>