<!doctype html>
<html lang="pl">



<body>
    @include('layout')

    <div class="container mt-5 mb-5">
        <div class="row mb-1" >
            <h1 style="text-align: center">Surowce</h1>
        </div>
        @can('is-admin')
        <div class="row mb-2" style="text-align: end">
            <a href="{{ route('materials.create') }}">Dodaj do cennika</a>
        </div>
        @endcan
        @if (session('error'))
            <div class="row d-flex justify-content-center">
                <div class="alert alert-danger">{{ session('error') }}</div>
            </div>
        @endif
        <div class="row">
            <table class="table table-hover table-striped">
                <thead>
                    <tr>
                        
                        <th scope="col">ID</th>
                        <th scope="col">Nazwa</th>
                        <th scope="col">Cena za 1kg</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($materials as $s)
                        <tr>
                            <th scope="row"><a href="{{ route('materials.show', $s->id) }}">{{ $s->id }}</a></th>
                            <td>{{ $s->nazwa }}</td>
                            <td>{{ $s->price }}</td>
                            <td>{{ $s->ilosc }}</td>
                            @can('is-admin')
                            <td><a href="{{route('materials.edit', $s->id)}}">Edycja</a></td>
                            
                            
                        </tr>
                        @endcan
                    @empty
                        <tr>
                            <th scope="row" colspan="6">Koszyk jest pusty.</th>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>


</body>

</html>
