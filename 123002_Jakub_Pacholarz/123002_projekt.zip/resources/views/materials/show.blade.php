<!doctype html>
<html lang="pl">



<body>
    @include('layout')

    <div class="container mt-5 mb-5">
        <div class="row mb-1">
            <h1>Surowiec</h1>
        </div>
        @if (session('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif
        <table class="table table-hover table-striped">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">#</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th scope="col">Nazwa</th>
                    <td>{{ $s->nazwa }}</td>
                </tr>
               
                <tr>
                    <th scope="col">Cena</th>
                    <td>{{ $s->price }}</td>
                </tr>
               
                <tr>
                    <th scope="col"></th>
                    <td><a href="{{ route('materials.edit', $s->id) }}"></a>
                        <form method="POST" action="{{ route('materials.destroy', $s->id) }}">
                            @csrf
                            @method('DELETE')
                        </div>
                        <input type="submit" value="Usuń"></button>
                        </form>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    
</body>

</html>
