<!doctype html>
<html lang="pl">



<body>
    @include('layout')

    <div class="container mt-5 mb-5">
        @if (session('error'))
            <div class="row d-flex justify-content-center">
                <div class="alert alert-danger">{{ session('error') }}</div>
            </div>
        @endif
        <div class="row mt-4 mb-4 text-center">
            <h1>Dodaj nowy surowiec</h1>
        </div>

        @if ($errors->any())
            <div class="row d-flex justify-content-center">
                <div class="col-6">
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
        @endif

        <div class="row d-flex justify-content-center">
            <div class="col-6">
                <form method="POST" action="{{ route('materials.store') }}" class="needs-validation" novalidate>
                    @csrf

                    <div class="form-group mb-2">
                        <label for="nazwa">Nazwa</label>
                        <input id="nazwa" name="nazwa" type="text" class="form-control">
                        <div class="invalid-feedback">Nieprawidłowe nazwa!</div>
                    </div>
                    
                    <div class="form-group mb-2">
                        <label for="price">Price</label>
                        <input id="price" name="price" type="text" class="form-control">
                        <div class="invalid-feedback">Nieprawidłowe nazwa!</div>
                    </div>

                  
                  
                   
                    
                    
                    <div class="text-center mt-4 mb-4">
                        <input class="btn btn-success" type="submit" value="Wyślij">
                    </div>
                </form>
            </div>
        </div>
    </div>

    
</body>

</html>