@extends('layout')
@section('title', "STORNA GŁÓWNA")
@section('content')
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  
  <title>Advanced HTML Page with Containers</title>
  <style>
    /* CSS styles */
    body {
      font-family: Arial, sans-serif;
      background-image: url(img/koparka.jpg) ;
      margin: 0;
      padding: 0;
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
    
    }
    footer {
            background-color: #333;
            padding: 10px;
            color: #fff;
            text-align: center;
        }
    
    header {
      background-color: #333;
      color: #fff;
      text-align: center;
    }
    
    .container {
     
      max-width: 800px;
      margin: 20px auto;
      padding: 20px;
      background-color: #fff;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    
    h1 {
      color: #333;
    }
    
    p {
      line-height: 1.5;
    }
    
    
    .button:hover {
      background-color: #555;
    }
    img {
  max-width: 100%;
  height: auto;
}
  </style>
</head>
<body>
  
  

  <div class="container">
    <h2 style="text-align: center">SUPER SUROWCE</h2>
    
    <p>Jest nam bardzo miło przedstawić Ci naszą firmę, specjalizującą się w sprzedaży surowców. Jesteśmy dynamicznym przedsiębiorstwem, które dostarcza wysokiej jakości surowce do różnych branż i sektorów gospodarki.</p>
    
    <p>You can add more content, such as images, forms, tables, and interactive elements to further enhance your page.W naszej ofercie znajdziesz różnorodne surowce, takie jak metale, minerały, chemikalia, drewno, tworzywa sztuczne i wiele innych. Współpracujemy z renomowanymi dostawcami, co gwarantuje nie tylko doskonałą jakość naszych produktów, ale także stabilność dostaw.</p>
    
    <p>Naszym celem jest nawiązanie długoterminowych relacji biznesowych opartych na zaufaniu i partnerstwie. Dlatego stawiamy na profesjonalną obsługę klienta, elastyczność w dostosowywaniu się do ich potrzeb oraz terminową realizację zamówień.</p>
</div>

<div class="container">
  <h2 style="text-align: center">Zesół</h2>
  
  <p>Nasz zespół składa się z doświadczonych ekspertów, którzy posiadają szeroką wiedzę na temat surowców i ich zastosowań. Dzięki temu możemy zapewnić naszym klientom najwyższą jakość produktów, które spełniają ich wymagania i oczekiwania.</p>
  

</div>


<div class="container">
  <h2 style="text-align: center">Zesół</h2>
  
  <p>Nasz zespół składa się z doświadczonych ekspertów, którzy posiadają szeroką wiedzę na temat surowców i ich zastosowań. Dzięki temu możemy zapewnić naszym klientom najwyższą jakość produktów, które spełniają ich wymagania i oczekiwania.</p>
  

</div>


</body>
</html>

<footer>
  &copy; 2023Jakub Pacholarz 
</footer>

@endsection