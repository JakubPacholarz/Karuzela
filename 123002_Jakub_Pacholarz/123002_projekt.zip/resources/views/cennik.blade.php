@extends('layout')
@section('title', "STORNA GŁÓWNA")
@section('content')
<!DOCTYPE html>
<html>
<head>
    <title>Sklep surowców</title>
    <style>
        body {
            
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }
        
        header {
            background-color: #1d1414;
            padding: 1%;
            color: #fff;
            text-align: center;
        }
        
        h1 {
            margin: 0;
        }
        
        main {
            padding: 20px;
        }
        
        footer {
            background-color: #333;
            padding: 10px;
            color: #fff;
            text-align: center;
        }
        
        .product {
            float: left;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            padding: 10px;
            
        }
        
        .product img {
            width: 100px;
            height: auto;
            float: center;
            
        }
        
        .product h3 {
            margin-top: 0;
        }
        
        .product p {
            margin-bottom: 0;
        }
        
       
   
    </style>
</head>
<body>
    <header>
        
    </header>
    
    <main>
        <div class="container text-center">
            <div class="row">
              <div class="col">
                <div class="product">
                    <img src="img/zloto.jpg" alt="Złoto">
                    <h3>Złoto</h3>
                    <p>Złoto jest cenionym surowcem o unikalnych właściwościach, które sprawiają, że jest wykorzystywane zarówno w przemyśle, jak i jako wartościowa forma inwestycji.</p>
                    
                    
                    
                </div>
              </div>
              <div class="col">
                <div class="product">
                    <img src="img/silver.png" alt="Srebro">
                    <h3>Miedź</h3>
                    <p>Srebro, ze względu na swoje doskonałe przewodnictwo elektryczne i termiczne, znajduje zastosowanie w wielu dziedzinach, od przemysłu elektronicznego po produkcję biżuterii.</p>
                </div>
              </div>

              <div class="col">
                <div class="product">
                    <img src="img/miedz.jpg" alt="miedz">
                    <h3>Miedź</h3>
                    <p>Miedź, ze względu na swoją wysoką przewodność elektryczną i odporność na korozję, jest niezastąpionym surowcem w branży elektrycznej i elektronicznej.</p>
                   
                    

                    
                </div>
              </div>
            </div>
          </div>
          <div class="container text-center">
            <div class="row">
              <div class="col">
                <div class="product">
                  <img src="img/zloto.jpg" alt="Złoto">
                    <h3>Złoto</h3>
                    <p>Złoto jest cenionym surowcem o unikalnych właściwościach, które sprawiają, że jest wykorzystywane zarówno w przemyśle, jak i jako wartościowa forma inwestycji.</p>
                    
                    
                    

                    
                </div>
              </div>
              <div class="col">
                <div class="product">
                    <<img src="img/miedz.jpg" alt="miedz">
                    <h3>Miedź</h3>
                    <p>Miedź, ze względu na swoją wysoką przewodność elektryczną i odporność na korozję, jest niezastąpionym surowcem w branży elektrycznej i elektronicznej.</p>
                   
                    
                  

                </div>
              </div>
              <div class="col">
                <div class="product">
                  <img src="img/silver.png" alt="Srebro">
                  <h3>Miedź</h3>
                  <p>Srebro, ze względu na swoje doskonałe przewodnictwo elektryczne i termiczne, znajduje zastosowanie w wielu dziedzinach, od pr
                    
                  

                    
                </div>
              </div>
            </div>
          </div>
          <div class="container text-center">
            <div class="row">
              <div class="col">
                <div class="product">
                    <img src="img/diament.jpg" alt="Surowiec 1">
                    <h3>Diamenty</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla consectetur mi sed justo accumsan fringilla.</p>
                    
                   

                    
                </div>
              </div>
              <div class="col">
                <div class="product">
                    <img src="img/zloto.jpg" alt="Surowiec 2">
                    <h3>Złoto</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla consectetur mi sed justo accumsan fringilla.</p>
                    

                   
                </div>
              </div>
              <div class="col">
                <div class="product">
                    <img src="img/silver.png" alt="Surowiec 3">
                    <h3>Srebro</h3>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla consectetur mi sed justo accumsan fringilla.</p>
                    
                    

                    
                </div>
              </div>
            </div>
          </div>
        
        
    </main>
    
    <footer>
        &copy; 2023Jakub Pacholarz 
    </footer>
</body>
</html>



@endsection