<?php

use App\Http\Controllers\AuthManager;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StoreController;
use App\Http\Controllers\MaterialController;
use App\Models\Zasoby;
use App\Http\Controllers\logController;
use App\Http\Controllers\ResourceController;
use App\Http\Controllers\rejController;
use App\Models\Material;
use App\Models\Resource;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/2', function () {
    return view('welcome');
    })->name ('home2');


Route::get('/login', [\App\Http\Controllers\logController::class, 'login'])->name('login');
Route::post('/login', [\App\Http\Controllers\logController::class, 'loginPost'])->name('login.post');
Route::get('/rejestracja',  [\App\Http\Controllers\rejController::class, 'rejestracja'])->name('rejestracja');
Route::post('/rejestracja', [\App\Http\Controllers\rejController::class, 'rejestracjaPost'])->name('rejestracja.post');
Route::get('/logout',[logController::class, 'logout'])->name('logout');



Route::resource('materials', MaterialController::class);



Route::controller(ResourceController::class)->group(function () {
    Route::get('/resourcess', 'index')->name('resourcess.index');
    Route::get('/resourcess/{id}', 'show')->name('resourcess.show');
    Route::get('/resourcess/{id}/edit', 'edit')->name('resourcess.edit');
    Route::put('/resourcess/{id}', 'update')->name('resourcess.update');
});


Route::get('/', function () {return view('welcomelogin');})->name ('home');
Route::get('/cennik', function(){return view('cennik');})->name ('cennik'); 
Route::get('/about', function(){return view('about');})->name ('about'); 