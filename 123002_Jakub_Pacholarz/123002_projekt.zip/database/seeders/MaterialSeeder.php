<?php

namespace Database\Seeders;

use App\Models\Material;
use App\Models\Surowce;
use App\Models\Zasoby;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;

class MaterialSeeder extends Seeder
{
   
    public function run(): void
    {
        Schema::withoutForeignKeyConstraints(function () {
            Material::truncate();
            Material::truncate();
        });

        Material::insert(
            [
                [
                    'nazwa' => 'złoto', 'price' => '100', 
                ],
                [
                    'nazwa' => 'srebro', 'price' => '75', 
                ],
                [
                    'nazwa' => 'miedź', 'price' => '44', 
                ],
                [
                    'nazwa' => 'aluminium', 'price' => '31', 
                ],
                [
                    'nazwa' => 'siarka', 'price' => '56', 
                ],
                [
                    'nazwa' => 'węgiel', 'price' => '87', 
                ],
                [
                    'nazwa' => 'marmur', 'price' => '33', 
                ],
                [
                    'nazwa' => 'gradient', 'price' => '77', 
                ],
                [
                    'nazwa' => 'piasek', 'price' => '90', 
                ],
            ]
        );
    }
}
