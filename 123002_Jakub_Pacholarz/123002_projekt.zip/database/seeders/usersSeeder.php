<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('users')->insert([
            [
                'name' => 'Jan', 
                'email' => 'jan@email.com', 
                'password' => Hash::make('1234'),
                'role_id' => 1,
                
            ],
            [
                'username' => 'AnnaNowak',
                'password' => 'test456',
                'email' => 'anna.nowak@example.com',
                
            ],
            [
                'username' => 'PiotrZielinski',
                'password' => 'passwd789',
                'email' => 'piotr.zielinski@example.com',
                
            ],
        ]);
    }
}

