<?php

namespace Database\Seeders;

use App\Models\Resource;
use App\Models\Surowce;
use App\Models\Zasoby;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Schema;

class ResourceSeeder extends Seeder
{
   
    public function run(): void
    {
        Resource::truncate();
        Resource::insert(
            [
                [
                    'name' => 'złoto', 'Typ' => 'szlachetny', 'ilosc => 190', 'id_materials=1'
                ],
                [
                    'name' => 'złoto', 'Typ' => 'szlachetny', 'ilosc => 180', 'id_materials=2'
                ],
                [
                    'name' => 'złoto', 'Typ' => 'szlachetny', 'ilosc => 170', 'id_materials=3'
                ],
                [
                    'name' => 'złoto', 'Typ' => 'szlachetny', 'ilosc => 160', 'id_materials=5'
                ],
                [
                    'name' => 'siarka', 'Typ' => 'chemiczne', 'ilosc => 150', 'id_materials=4' 
                ],
                [
                    'name' => 'węgiel', 'Typ' => 'chemiczne',  'ilosc => 140', 'id_materials=6'
                ],
                [
                    'name' => 'marmur', 'Typ' => 'budowlane',  'ilosc => 130', 'id_materials=7'
                ],
                [
                    'name' => 'gradient', 'Typ' => 'budowlane',  'ilosc => 120', 'id_materials='
                ],
                [
                    'name' => 'piasek', 'Typ' => 'budowlane',  'ilosc => 110', 'id_materials=8'
                ],
            ]
        );
    }
}
