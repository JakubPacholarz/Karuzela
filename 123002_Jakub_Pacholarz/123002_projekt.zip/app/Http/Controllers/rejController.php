<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;



class rejController extends Controller
{



    public function rejestracja()
    {
        if (Auth::check()) {
            return redirect()->route('welcomelogin');
        }
        return view('rejestracja');
    }


function rejestracjaPost(Request $request){
    
    $validatedData = $request->validate([
        'name' => 'required',
        'email' => 'required|email|unique:users',
        'password' => 'required',
        
        ]);

       $data['name'] = $request->name;
       $data['email'] = $request->email;
       $data['password'] = Hash::make($request->password);
       $user = User::create($data);

       if (!$user)
       {
        return redirect(route('rejestracja'))->with("error", "Spróbuj ponownie");
       }
            return redirect(route('login'))->with("Sukces", "Rejestracja zakończona skucesem");
            
            
           
    }
}