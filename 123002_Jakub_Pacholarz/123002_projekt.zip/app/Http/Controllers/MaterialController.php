<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreMaterialRequest;
use App\Http\Requests\UpdateMaterialRequest;
use App\Models\Material;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class MaterialController extends Controller
{


    public function index()
    {
        return view('materials.index', [
            'materials' => Material::all()
        ]);
    }

    public function create()
    {
        return view('materials.create');
    }

    public function store(StoreMaterialRequest $request)
    {
        $input = $request->all();
        Material::create($input);

        return redirect()->route('materials.index');
    }
    public function show(Material $material)
    {
        return view('materials.show', [
            's' => $material
        ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Material $material)
    {
        return view('materials.edit', ['s' => $material]);
    }

    /**
     * Update the specified resource in storage.
     */
   
     public function update(Request $request, Material $material)
     {
        
         $input = $request->all();
         Log::channel('stderr')->info(print_r($input));
         $material->update($input);
        return redirect()->route('materials.index');
     }
    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Material $materials)
    {
        $materials->delete();
        return redirect()->route('materials.index');
    }

    
}

