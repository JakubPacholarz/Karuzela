<?php

namespace App\Http\Controllers;

use App\Models\Material;
use App\Models\Resource;
use Illuminate\Http\Request;

class ResourceController extends Controller
{
    public function index(){
        return view('resourcess.index', [
            'resourcess' => Resource::all(),
            
        ]);
    }

    public function show($id)
    {
        return view('resourcess.show', [
            't' => Resource::findOrFail($id)
        ]);
    }

    public function edit($id)
    {
        $resource  = Resource::findOrFail($id);
        return view('resourcess.edit', [
            't' => $resource,
            'materials ' => Material::all()
        ]);
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nazwa' => 'required|string',
            'typ' => 'string',
            
            
        ]);

        $resourcess = Resource::findOrFail($id);
        $input = $request->all();
        $resourcess->update($input);
        return redirect()->route('resourcess.index');
    }

    public function destroy(Resource $resourcess)
    {
        $resourcess->delete();
        return redirect()->route('resourcess.index');
    }
}
