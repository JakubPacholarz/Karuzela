package zadanie3.pkg1.pkg1;


public class Zadanie311 {
    
    public static void main(String[] args) {
     double a=12.12;
     
     System.out.println(a--);
     System.out.println(a++);
     System.out.println(--a);
     System.out.println(++a);
    }
    
}
