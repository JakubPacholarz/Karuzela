package zadanie3.pkg2.pkg2;

public class Zadanie322 {

    public static void main(String[] args) {
        int a = 3 & 4; // 3 = 011, 4 = 100
        int b = 3 | 4;
        System.out.print("3 & 4=" + a + "\n"); //stąd a = 0
        System.out.print("3 | 4=" + b + "\n"); //stąd b = 7

    }
    
}
