package zadanie3.pkg2.pkg4;

public class Zadanie324 {

    public static void main(String[] args) {
        int a = 17;
        double b = 4.0;
        System.out.println(a += b);
        System.out.println(a -= b);
        System.out.println(a *= b);
        System.out.println(a /= b);
        System.out.println(a %= b);
    }

}
