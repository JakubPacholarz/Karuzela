package zadanie3.pkg2.pkg6;

public class Zadanie326 {

    public static void main(String[] args) {
        boolean a = true;
        System.out.println(!a);
        boolean b = 0==0 ^ 2==3;
        System.out.println(b);
    }

}
