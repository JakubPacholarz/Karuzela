package zadanie3.pkg2.pkg3;

public class Zadanie323 {

    public static void main(String[] args) {
        int a,b,c;
        a = 4 >> 2;
        b = a << 3;
        c = b >>> 2;
        System.out.println("4 >> 2 = " + a + "\na << 3 = " + b + "\nb >>> 2 = " + c);
    }
    
}
