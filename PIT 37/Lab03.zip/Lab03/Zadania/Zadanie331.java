package zadanie3.pkg3.pkg1;

public class Zadanie331 {
    
    public static void main(String[] args) {
    import java.util.*;
    }
}
