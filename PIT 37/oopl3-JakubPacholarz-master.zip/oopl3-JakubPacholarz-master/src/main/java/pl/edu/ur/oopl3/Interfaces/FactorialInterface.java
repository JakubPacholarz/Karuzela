package pl.edu.ur.oopl3.Interfaces;

/**
 */
public interface FactorialInterface {
    public int factorial(int i);
}
