package pl.edu.ur.oopl3.Zad3_4;

import pl.edu.ur.oopl3.Interfaces.FibonacciInterface;

/**
 */
public class Fibonacci implements FibonacciInterface {
    @Override
    public int sumOfFicbonacci(int numberOfElement) {
        return 0;
    }
}
