package pl.edu.ur.oopl3.Interfaces;

/**
 */
public interface FibonacciInterface {

    public int sumOfFicbonacci(int numberOfElement);
}
