package pl.edu.ur.oopl3.Interfaces;

/**
 */
public interface PowerInterface {

    public double recursionPow(double a, double b);
    public double noRecursionPow(double a, double b);
}
