package pl.edu.ur.oopl3.Zad3_3;

import pl.edu.ur.oopl3.Interfaces.PowerInterface;

/**
 */
public class Power implements PowerInterface {

    @Override
    public double recursionPow(double a, double b) {
        return 0;
    }

    @Override
    public double noRecursionPow(double a, double b) {
        return 0;
    }
}
