package pl.edu.ur.oopl3.Zad3_2;

import pl.edu.ur.oopl3.Interfaces.FactorialInterface;

/**
 */
public class NoRecursionFactorial implements FactorialInterface {

    @Override
    public int factorial(int i) {
        return 0;
    }
}
